<?php
/** ↓↓↓
 * $API_KEY :: التوكن
 **/
$API_KEY = "123:abc";

/** ↓↓↓
 * $PASS ::
 * كلمة المرور لأغراض الحماية
 * قم بتغييرها حسب ما تريد
 * لا تستخدم الاشارات التالية
 * + = & _
 **/
$PASSURL = "hassan";

/** ↓↓↓
 * $dir ::
 * رابط مجلد السورس
 * index.php بدون
 * / لا تنسى علامة ال
 **/
$url_dir = "https://example.com/code/";

/** ↓↓↓
 * $admins :
 * ايديات مدراء البوت
 */

$admins = array(604978176,619425597);

/** ↓↓↓
 * /start رسالة شرط ال
 **/

$start = "Hello world! 🌚"."\n"."@api_tele";

/** ↓↓↓
 * @ معرف البوت بدون 
 * DRAGON404_BOT قم بوضع المعرف مكان
 **/
 
$userbot = "@"."DRAGON404_BOT";

/** ↓↓↓
 * صنع ويب هوك 
 * webhook.php قم بالدخول على صفحة
 * https://example.com/code/webhook.php
 **/
 

/**
 * curl 
 **/
 
function getfromurl($url){
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
  $res = curl_exec($ch);
  return $res;
}


/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 
?>