<head><meta charset="UTF-8"> </head>
<?php
//header('content-type:application/json; charset=utf-8');

/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 
include("Connection.php");
$PASS = filter_var($_GET['pass'],FILTER_SANITIZE_STRING);

if($PASS != $PASSURL){
  die("كلمة المرور خاطئة");
}

echo 'done';
ob_start();
define("API_KEY",$API_KEY);

function bot($method,$datas=[]){
  $url = "https://api.telegram.org/bot".API_KEY."/".$method;
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
  $res = curl_exec($ch);
  if(curl_error($ch)){
    var_dump(curl_error($ch));
  }else{
    return json_decode($res);
  }
}

$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$message_id = $message->message_id;
$ex = explode(' ',$text);
$type = $message->chat->type;
$name = $message->from->first_name;
$user = $message->from->username;

if(isset($update->callback_query->data)){
  $callback = $update->callback_query;
  $data = $callback->data;
  $chat_id = $callback->message->chat->id;
  $message_id = $callback->message->message_id;
  $id = $callback->from->id;
  $name = $callback->from->first_name;
  $user = $callback->from->username;
}

if($text == "/start" && $type == "private"){
  bot("sendMessage",[
    "chat_id"=>$chat_id,
    "text"=>"🔐",
    reply_to_message_id=>$message_id,
  ]);
  if(in_array($id,$admins)){
    bot("sendMessage",[
      "chat_id"=>$chat_id,
      "text"=>"أنت أدمن في هذا البوت يمكنك تجربة الأكواد الآن"."\n".$start."\n"."Your id : $id",
      reply_to_message_id=>$message_id,    
    ]);
  }else{
    bot("sendMessage",[
      "chat_id"=>$chat_id,
      "text"=>$start."\n"."Your id : $id",
      reply_to_message_id=>$message_id,
    ]);
    foreach ($admins as $admin){
      bot("sendMessage",[
        "chat_id"=>$admin,
        "text"=>"<a href='tg://user?id=$id'>$name</a>",
        'parse_mode'=>"Html",
      ]);
    }
  }
  die("");
}


if(in_array($id,$admins)){
  if(($ex[0] == '/up' or $ex[0] == '/up'.$userbot) and $ex[1] != null){
    if($text){
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"تم رفع الكود",
        "reply_to_message_id"=>$message_id,
      ]);

      $texte = str_replace("/up","",$text);
      $texte = str_replace("/up".$userbot,"",$texte);
      file_put_contents("code.php","<?php $texte");
    }
    
    if($text){
      $g = json_decode(getfromurl($url_dir."do.php"))->error;
      //$g = filter_var($g,FILTER_SANITIZE_STRING);
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>strip_tags($g),
        'parse_mode'=>"Html",
      ]);
    }
  }




  if(($ex[0] == '/add' or $ex[0] == '/add'.$userbot) and $ex[1] != null){
    if($text){
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"تم إضافة الكود",
        reply_to_message_id=>$message_id,
      ]);
      $text = str_replace("/add","",$text);
      $text = str_replace("/add".$userbot,"",$text);
      file_put_contents("code.php","\n$text",FILE_APPEND);
    }

    if($text){
      $g = json_decode(getfromurl($url_dir."do.php?code=". $g))->error;
      //$g = filter_var($g,FILTER_SANITIZE_STRING);
      bot("sendMessage",[    
        "chat_id"=>$chat_id,
        "text"=>strip_tags($g),
        'parse_mode'=>"Html",
    ]);
    }
    }



  if(($ex[0] == '/test' or $ex[0] == '/test'.$userbot) and $ex[1] != null){
    if($text){
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"تم رفع الكود ليتم فحصه",
        reply_to_message_id=>$message_id,
      ]);  
      //$text = str_replace("\n","",$text);
      $text = str_replace("/test","",$text);
      $text = str_replace("/test".$userbot,"",$text);
      file_put_contents("code.php","<?php $text ?>");
    }

    if($text){
      $g = json_decode(getfromurl($url_dir."do.php?code=". $g))->error;
      //$g = filter_var($g,FILTER_SANITIZE_STRING);
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>strip_tags($g),
      ]);
      file_put_contents("code.php","");
    }
  }

  $f = explode("?",$text);
  $e = explode("=", $f[1]);
  $x = str_replace(" ","%20",$e[1]);
  if((($f[0] == '/load' or $f[0] == '/load'.$userbot) && $f[1] != null  ) or $text == "/load" or $text == "/load".$userbot){
    if($text){
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"جار تحميل الصفحة",
        reply_to_message_id=>$message_id,
    ]);
    }

    if($text){
      $gy = json_decode(getfromurl($url_dir."do.php?code=". $e[0]."&k=".$x))->error;
      //$g = filter_var($g,FILTER_SANITIZE_STRING);
      $g = str_replace("لا يوجد أخطاء","",$gy);
      if($gy != "لا يوجد أخطاء\n"){
        bot("sendMessage",[
          "chat_id"=>$chat_id,
          "text"=>strip_tags($g),
        ]);
      }
      if($gy == "لا يوجد أخطاء\n"){
        bot("sendMessage",[    
          "chat_id"=>$chat_id,
          "text"=>"الصفحة فارغة",
        ]);
      }
    }
  }



  if($text == '/getme' or $text == '/getme'.$userbot ){
    bot("sendMessage",[
      "chat_id"=>$chat_id,
      "text"=>"انتظر قليلا",
      reply_to_message_id=>$message_id,
    ]);


    $g = file_get_contents("code.php");
    if($text and $g != null){
      bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>$g,
      ]);
    }else{
        bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"🤷‍♂",
      ]);
    }
  }



  if($text == "/del" or $text == '/del'.$userbot){
    file_put_contents("code.php","");
    bot("sendMessage",[
      "chat_id"=>$chat_id,
      "text"=>"تم الحذف بنجاح",
      reply_to_message_id=>$message_id,
    ]);
  }
}


$messageed = $update->edited_message;
$ided = $messageed->from->id;
$chat_ided = $messageed->chat->id;
$texted = $messageed->text;
$message_ided = $messageed->message_id;
$up = "up".$userbot;

if(in_array($ided,$admins)){
  if(preg_match('/up/',$texted) or preg_match("/$up/",$texted)){
    if($messageed){
      bot("sendMessage",[
        "chat_id"=>$chat_ided,
        "text"=>"تم حفظ التعديل",
        reply_to_message_id=>$message_ided,
      ]);
      $texted = str_replace("/up","",$texted);
      $texted = str_replace($up,"",$texted);
      file_put_contents("code.php","<?php $texted ?>");
    }

    if($messageed){
      $g = json_decode(getfromurl($url_dir."do.php?code=". $g))->error;
      //$g = filter_var($g,FILTER_SANITIZE_STRING);
      bot("sendMessage",[
        "chat_id"=>$chat_ided,
        "text"=>strip_tags($g),
      ]);
    }
  }
}



if(in_array($id,$admins)){
  $g = json_decode(getfromurl($url_dir."do.php?code=". $g))->ok;
  if ( $g == "true"){
    include("code.php");
  }
}


/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 ?>