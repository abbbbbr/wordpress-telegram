<?php


/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 
 
include("Connection.php");
//header('Content-Type: application/json;charset=utf-8');

ob_start();

$root = realpath("");

$code = filter_var($_GET['code'],FILTER_SANITIZE_STRING);
$k = filter_var(urlencode($_GET['k']),FILTER_SANITIZE_STRING);

$go = getfromurl($url_dir."code.php?$code=$k");
$go= str_replace($root,"****/**/***",$go);

if(preg_match('/error/',$go)){
   $ok['ok'] = "false";
   $ok['error'] = "يوجد خطأ"."\n"."$go";
   echo json_encode($ok,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

}elseif(preg_match('/Warning/',$go)){
   $ok['ok'] = "false";
   $ok['error'] = "تحذير!"."\n"."$go";
   echo json_encode($ok,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}else{
   $ok['ok'] = "true";
   $ok['error'] = "لا يوجد أخطاء"."\n".$go;
   echo json_encode($ok);
      
}
?>
          