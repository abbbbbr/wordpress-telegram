<?php

/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 
include("Connection.php");
$set = json_decode(getfromurl("https://api.telegram.org/bot".$API_KEY."/setwebhook?url=".$url_dir."index.php?pass=".$PASSURL))->description;
if($set == "Webhook was set" ){
  echo '<p style="font-size:5vw;text-align:center;background:green;color:white;">تم بنجاح</p>';
}elseif($set == "Webhook is already set" ){
  echo '<p style="font-size:5vw;text-align:center;background:grey;color:white;">الويب هوك موجود بالفعل</p>';
}else{
  echo '<p style="font-size:5vw;text-align:center;background:red;color:white;">فشل</p>';
  echo '<p style="font-size:5vw;text-align:center;background:red;color:white;">'.$set.'</p>';
}

/**
 * تمت برمجة هذا البوت 
 * من قبل فريق
 * @api_tele
 * لا تقم بتعديل أي شيء
 * Connection.php فقط بالملف
 * بعد تعديل الملف قم بالولوج 
 * إلى رابط الملف
 * webhook.php
 * لعمل ويب هوك
 * 
 * @api_tele
 * @bot_tele1
 **/
 
?>